package net.danial.myapplication3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate (R.menu.menu, menu);

        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.about:

                Toast.makeText(this,"This is About Us", Toast.LENGTH_LONG).show();

                Intent intent = new Intent(this, AboutActivity.class);
                startActivity(intent);

                break;

            case R.id.keep:

                Toast.makeText(this,"This is for Keeps Gold", Toast.LENGTH_LONG).show();

                Intent intent1 = new Intent(this, KeepActivity.class);
                startActivity(intent1);

                break;

            case R.id.wear:

                Toast.makeText(this,"This is for Wears Gold", Toast.LENGTH_LONG).show();

                Intent intent2 = new Intent(this, WearActivity.class);
                startActivity(intent2);

                break;


        }

        return super.onOptionsItemSelected(item);
    }


}