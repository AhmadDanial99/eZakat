package net.danial.myapplication3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class WearActivity extends AppCompatActivity implements View.OnClickListener {

    EditText etGram, etValues;
    TextView tvOuput;
    Button buttonCalc;



    int uruf = 200;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wear);

        etGram = (EditText) findViewById(R.id.etGram);
        etValues = (EditText) findViewById(R.id.etValues);
        tvOuput = (TextView) findViewById(R.id.tvOutput);
        buttonCalc = (Button) findViewById(R.id.buttonCalc);

        buttonCalc.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.buttonCalc:
                double gram = Double.parseDouble(etGram.getText().toString());
                double value = Double.parseDouble(etValues.getText().toString());

                double keep = gram - uruf;
                if (keep > 0) {
                    keep = keep;
                }
                else {
                    keep = 0;
                }

                double zakatPayable = keep * value;
                double total = zakatPayable * 0.025;

                tvOuput.setText("Total Weight :" + gram +
                        "\n Zakat Payable : RM" + zakatPayable+
                        "\n Total Zakat : RM" + total);

                break;
        }

    }
}